<?php

require "vendor/autoload.php";

use Auth0\SDK\Auth0;

$auth0 = new Auth0([
  'domain' => 'myphpnotes.auth0.com',
  'client_id' => 'z9CdRcbKJk1a1OwNVpvQNa8uV41E93Gn',
  'client_secret' => 'ofHfuegyZG8qJ4GB85ObLbj-yUrBpS_Gb1e_MhXSzN8UEukX4Ingg5H0CFDaT0U9',
  'redirect_uri' => 'http://exercise2.org/callback.php',
  'audience' => 'https://myphpnotes.auth0.com/userinfo',
  'persist_id_token' => true,
  'persist_access_token' => true,
  'persist_refresh_token' => true,
]);