<?php

require "vendor/autoload.php";

use Auth0\SDK\Auth0;

$auth0 = new Auth0([
  'domain' => 'myphpnotes.auth0.com',
  'client_id' => 'KPFp4FTuurQfQwOAC7qLrH6hjV0XrLZK',
  'client_secret' => 'mIcb1yz0kk7wdc496VXXftH06ZEqU_2XQ7Cn37iKe7ZZCIiyTnuw79AdnyngN0MO',
  'redirect_uri' => 'http://exercise.org/callback.php',
  'audience' => 'https://myphpnotes.auth0.com/userinfo',
  'persist_id_token' => true,
  'persist_access_token' => true,
  'persist_refresh_token' => true,
]);